package DI_Annotation_03;

public class Recorder {

}
