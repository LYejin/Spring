package DI_Annotation_04_javaconfig;

public class User2 {
	public void userMethod2() {
		System.out.println("User2 클래스 함수");
	}
}
