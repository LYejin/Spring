package DI_Annotation_04_javaconfig;

public class User {
	public void userMethod() {
		System.out.println("User 클래스 함수");
	}
}
