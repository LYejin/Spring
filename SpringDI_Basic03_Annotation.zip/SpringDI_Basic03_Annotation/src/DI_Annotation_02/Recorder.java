package DI_Annotation_02;

public class Recorder {

}
