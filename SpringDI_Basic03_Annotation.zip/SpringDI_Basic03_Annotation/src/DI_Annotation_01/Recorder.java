package DI_Annotation_01;

public class Recorder {

}
