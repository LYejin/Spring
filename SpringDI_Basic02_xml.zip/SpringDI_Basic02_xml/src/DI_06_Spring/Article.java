package DI_06_Spring;

//DB테이블과 1:1매핑
public class Article {
	//member field
	//setter, getter
	//생성자 ...constructor
	//toString
}
