package DI_02;

public interface MessageBean {
	void sayHello(String name);
}
