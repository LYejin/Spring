package DI_07_Spring;

//부모역할 (다형성)
public interface MyFilter {
	
}
